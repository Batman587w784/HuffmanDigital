/* @ds-bundle: {"format":4,"namespace":"HuffmanConstructionDesignSystem_a62619","components":[{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"SectionHeading","sourcePath":"components/display/SectionHeading.jsx"},{"name":"Stat","sourcePath":"components/display/Stat.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Textarea","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/display/Badge.jsx":"b61825fd606f","components/display/Card.jsx":"92c7b6ce6aa9","components/display/SectionHeading.jsx":"ad96285eb5ff","components/display/Stat.jsx":"599d448cf0ea","components/forms/Button.jsx":"7a9ff3f49bd5","components/forms/Checkbox.jsx":"14a54c7b85b0","components/forms/Input.jsx":"e870dfaa6924","components/forms/Select.jsx":"6e926c287d16","components/navigation/Tabs.jsx":"af8ef32e378c","ui_kits/website/pages.jsx":"05cb7027a5b0","ui_kits/website/sections.jsx":"9d85b7cc2de1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.HuffmanConstructionDesignSystem_a62619 = window.HuffmanConstructionDesignSystem_a62619 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/display/Badge.jsx
try { (() => {
/** Small squared label. tone: brand | navy | neutral | success | warning | danger. outline for bordered style. */
function Badge({
  tone = "brand",
  outline = false,
  children,
  style
}) {
  const tones = {
    brand: ["var(--hc-blue-600)", "var(--hc-blue-50)", "var(--hc-blue-700)"],
    navy: ["var(--hc-blue-900)", "#e8edf4", "var(--hc-blue-900)"],
    neutral: ["var(--hc-gray-500)", "var(--hc-gray-100)", "var(--hc-gray-700)"],
    success: ["var(--hc-success)", "#e7f2ea", "var(--hc-success)"],
    warning: ["var(--hc-warning)", "#f6eddd", "var(--hc-warning)"],
    danger: ["var(--hc-danger)", "#f6e7e7", "var(--hc-danger)"]
  };
  const [solid, tint, text] = tones[tone] || tones.brand;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      padding: "4px 10px",
      borderRadius: "var(--radius-sm)",
      background: outline ? "transparent" : tint,
      color: text,
      border: outline ? `1px solid ${solid}` : "1px solid transparent",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
/** White card. If image/imageLabel given, renders a flush photo (or placeholder) header. */
function Card({
  image,
  imageLabel,
  title,
  meta,
  children,
  lifted = false,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      boxShadow: lifted ? "var(--shadow-card)" : "none",
      overflow: "hidden",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, (image || imageLabel) && /*#__PURE__*/React.createElement("div", {
    style: {
      height: 180,
      background: image ? `url(${image}) center/cover no-repeat` : "var(--hc-gray-200)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--hc-gray-500)",
      fontSize: 13,
      letterSpacing: "0.06em",
      textTransform: "uppercase"
    }
  }, !image && (imageLabel || "Photo")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 20px 20px"
    }
  }, meta && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      fontWeight: 600,
      letterSpacing: "var(--tracking-kicker)",
      textTransform: "uppercase",
      color: "var(--brand)",
      marginBottom: 6
    }
  }, meta), title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-serif-display)",
      fontWeight: 700,
      fontSize: 20,
      color: "var(--text-heading)",
      lineHeight: 1.25,
      marginBottom: children ? 8 : 0
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      lineHeight: 1.55,
      color: "var(--text-body)"
    }
  }, children)));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/SectionHeading.jsx
try { (() => {
/** Signature section heading: uppercase kicker, serif heading, 3px brand rule. align: left | center. */
function SectionHeading({
  kicker,
  title,
  lead,
  align = "left",
  onDark = false,
  style
}) {
  const center = align === "center";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: center ? "center" : "left",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, kicker && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      fontWeight: 600,
      letterSpacing: "var(--tracking-kicker)",
      textTransform: "uppercase",
      color: onDark ? "var(--hc-blue-400)" : "var(--brand)"
    }
  }, kicker), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-serif-display)",
      fontWeight: 700,
      fontSize: "var(--text-h2)",
      lineHeight: "var(--leading-heading)",
      letterSpacing: "var(--tracking-display)",
      color: onDark ? "#fff" : "var(--text-heading)",
      margin: kicker ? "10px 0 0" : 0
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: "var(--rule-w)",
      background: "var(--brand)",
      margin: center ? "16px auto 0" : "16px 0 0"
    }
  }), lead && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-lead)",
      lineHeight: 1.55,
      color: onDark ? "var(--text-on-dark-muted)" : "var(--text-body)",
      maxWidth: 640,
      margin: center ? "18px auto 0" : "18px 0 0"
    }
  }, lead));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/display/Stat.jsx
try { (() => {
/** Big serif number + label. onDark for navy stat bands. */
function Stat({
  value,
  label,
  onDark = false,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-serif-display)",
      fontWeight: 700,
      fontSize: 48,
      lineHeight: 1.05,
      letterSpacing: "-0.01em",
      color: onDark ? "#fff" : "var(--text-heading)"
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6,
      fontSize: 13,
      fontWeight: 600,
      letterSpacing: "var(--tracking-kicker)",
      textTransform: "uppercase",
      color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)"
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Stat.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Huffman button. variant: primary | secondary | ghost | onDark. size: sm | md | lg */
function Button({
  variant = "primary",
  size = "md",
  disabled = false,
  children,
  style,
  ...rest
}) {
  const [state, setState] = React.useState("rest"); // rest | hover | press
  const sizes = {
    sm: {
      padding: "8px 16px",
      fontSize: 13.5
    },
    md: {
      padding: "11px 22px",
      fontSize: 15
    },
    lg: {
      padding: "14px 30px",
      fontSize: 16
    }
  };
  const palettes = {
    primary: {
      rest: {
        background: "var(--hc-blue-600)",
        color: "#fff",
        border: "1px solid transparent"
      },
      hover: {
        background: "var(--hc-blue-700)"
      },
      press: {
        background: "var(--hc-blue-800)"
      }
    },
    secondary: {
      rest: {
        background: "#fff",
        color: "var(--hc-blue-700)",
        border: "1px solid var(--hc-blue-600)"
      },
      hover: {
        background: "var(--hc-blue-50)"
      },
      press: {
        background: "var(--hc-blue-100)"
      }
    },
    ghost: {
      rest: {
        background: "transparent",
        color: "var(--hc-blue-700)",
        border: "1px solid transparent"
      },
      hover: {
        background: "var(--hc-blue-50)"
      },
      press: {
        background: "var(--hc-blue-100)"
      }
    },
    onDark: {
      rest: {
        background: "#fff",
        color: "var(--hc-blue-800)",
        border: "1px solid transparent"
      },
      hover: {
        background: "var(--hc-blue-50)"
      },
      press: {
        background: "var(--hc-blue-100)"
      }
    }
  };
  const p = palettes[variant] || palettes.primary;
  const merged = {
    fontFamily: "var(--font-sans)",
    fontWeight: 600,
    letterSpacing: "0.01em",
    borderRadius: "var(--radius-md)",
    cursor: disabled ? "not-allowed" : "pointer",
    transition: "background var(--duration-fast) var(--ease-standard), color var(--duration-fast) var(--ease-standard)",
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    ...sizes[size],
    ...p.rest,
    ...(state === "hover" && !disabled ? p.hover : null),
    ...(state === "press" && !disabled ? p.press : null),
    ...(disabled ? {
      background: "var(--hc-gray-200)",
      color: "var(--hc-gray-500)",
      border: "1px solid transparent"
    } : null),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: merged,
    onMouseEnter: () => setState("hover"),
    onMouseLeave: () => setState("rest"),
    onMouseDown: () => setState("press"),
    onMouseUp: () => setState("hover")
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
/** Square checkbox with label. Controlled or uncontrolled. */
function Checkbox({
  label,
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
  style
}) {
  const [internal, setInternal] = React.useState(defaultChecked);
  const isOn = checked !== undefined ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    if (checked === undefined) setInternal(!isOn);
    onChange && onChange(!isOn);
  };
  return /*#__PURE__*/React.createElement("label", {
    onClick: toggle,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: disabled ? "var(--text-muted)" : "var(--text-body)",
      userSelect: "none",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flex: "none",
      borderRadius: "var(--radius-sm)",
      border: `1px solid ${isOn ? "var(--hc-blue-600)" : "var(--border-strong)"}`,
      background: disabled ? "var(--hc-gray-100)" : isOn ? "var(--hc-blue-600)" : "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "background var(--duration-fast) var(--ease-standard)"
    }
  }, isOn && /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 12 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 6.2 4.8 9 10 3.4",
    stroke: "#fff",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Labeled text input. */
function Input({
  label,
  hint,
  error,
  type = "text",
  placeholder,
  value,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "block",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text-heading)",
      marginBottom: 6
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      boxSizing: "border-box",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: "var(--text-body)",
      padding: "11px 12px",
      background: "#fff",
      border: `1px solid ${error ? "var(--hc-danger)" : focus ? "var(--hc-blue-600)" : "var(--border-strong)"}`,
      borderRadius: "var(--radius-sm)",
      outline: "none",
      boxShadow: focus ? "var(--focus-ring)" : "none",
      transition: "box-shadow var(--duration-fast) var(--ease-standard)"
    }
  }, rest)), (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: 12.5,
      marginTop: 5,
      color: error ? "var(--hc-danger)" : "var(--text-muted)"
    }
  }, error || hint));
}

/** Multiline variant sharing the same styling. */
function Textarea({
  label,
  hint,
  error,
  placeholder,
  value,
  onChange,
  rows = 4,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "block",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text-heading)",
      marginBottom: 6
    }
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    rows: rows,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      boxSizing: "border-box",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: "var(--text-body)",
      padding: "11px 12px",
      background: "#fff",
      border: `1px solid ${error ? "var(--hc-danger)" : focus ? "var(--hc-blue-600)" : "var(--border-strong)"}`,
      borderRadius: "var(--radius-sm)",
      outline: "none",
      resize: "vertical",
      boxShadow: focus ? "var(--focus-ring)" : "none"
    }
  }, rest)), (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: 12.5,
      marginTop: 5,
      color: error ? "var(--hc-danger)" : "var(--text-muted)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input, Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Labeled native select. options: [{value,label}] or ["a","b"]. */
function Select({
  label,
  hint,
  options = [],
  value,
  onChange,
  placeholder,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const opts = options.map(o => typeof o === "string" ? {
    value: o,
    label: o
  } : o);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "block",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text-heading)",
      marginBottom: 6
    }
  }, label), /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      boxSizing: "border-box",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: "var(--text-body)",
      padding: "11px 12px",
      background: "#fff",
      border: `1px solid ${focus ? "var(--hc-blue-600)" : "var(--border-strong)"}`,
      borderRadius: "var(--radius-sm)",
      outline: "none",
      boxShadow: focus ? "var(--focus-ring)" : "none"
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), opts.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: 12.5,
      marginTop: 5,
      color: "var(--text-muted)"
    }
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/** Underline tabs. items: string[]. Controlled (active/onChange) or uncontrolled. */
function Tabs({
  items = [],
  active,
  defaultActive = 0,
  onChange,
  style
}) {
  const [internal, setInternal] = React.useState(defaultActive);
  const idx = active !== undefined ? active : internal;
  const [hover, setHover] = React.useState(-1);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 28,
      borderBottom: "1px solid var(--border-default)",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, items.map((item, i) => {
    const on = i === idx;
    return /*#__PURE__*/React.createElement("button", {
      key: item,
      type: "button",
      onClick: () => {
        if (active === undefined) setInternal(i);
        onChange && onChange(i);
      },
      onMouseEnter: () => setHover(i),
      onMouseLeave: () => setHover(-1),
      style: {
        background: "none",
        border: "none",
        padding: "10px 2px 12px",
        marginBottom: -1,
        cursor: "pointer",
        fontFamily: "var(--font-sans)",
        fontSize: 15,
        fontWeight: on ? 600 : 500,
        color: on ? "var(--hc-blue-700)" : hover === i ? "var(--hc-blue-600)" : "var(--text-muted)",
        borderBottom: `3px solid ${on ? "var(--brand)" : "transparent"}`,
        transition: "color var(--duration-fast) var(--ease-standard)"
      }
    }, item);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/pages.jsx
try { (() => {
// Page-level views: Projects index, About, Contact (bid request).
const {
  Button,
  Input,
  Select,
  Textarea,
  Checkbox,
  Stat,
  SectionHeading,
  Tabs
} = window.HuffmanConstructionDesignSystem_a62619;
function ProjectsPage() {
  const cats = ["All Projects", "Commercial", "Institutional", "Residential", "Specialty"];
  const [i, setI] = React.useState(0);
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Projects page"
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "72px 0 var(--section-pad)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: HCwrap
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "Our Work",
    title: "Projects",
    lead: "A selection of recent work across our four divisions. Most were built for repeat clients."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: "40px 0 36px"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    items: cats,
    active: i,
    onChange: setI
  })), /*#__PURE__*/React.createElement(HCProjectGrid, {
    filter: cats[i]
  }))));
}
function ServicesPage() {
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Services page"
  }, /*#__PURE__*/React.createElement(HCServices, null), /*#__PURE__*/React.createElement(HCStatsBand, null));
}
function AboutPage() {
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "About page"
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "72px 0 var(--section-pad)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...HCwrap,
      display: "grid",
      gridTemplateColumns: "1.1fr 1fr",
      gap: 64,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "About Us",
    title: "Nearly Four Decades of Word-of-Mouth Work"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "16px/1.7 var(--font-sans)",
      color: "var(--text-body)",
      margin: "28px 0 0"
    }
  }, "Huffman Corporation was established in Bridgeport, West Virginia, and has grown almost entirely by referral. We serve North Central West Virginia with commercial, residential, institutional, and specialty construction."), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "16px/1.7 var(--font-sans)",
      color: "var(--text-body)",
      margin: "16px 0 0"
    }
  }, "The company is led today by owner Wayne Huffman. Our clients come back because we deliver what we bid, on the schedule we committed to."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 48,
      marginTop: 40
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "1988",
    label: "Established"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "80%",
    label: "Repeat Clients"
  }))), /*#__PURE__*/React.createElement(HCPhotoPlaceholder, {
    label: "Team / jobsite photo",
    height: 420
  }))));
}
function ContactPage() {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Contact page"
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "72px 0 var(--section-pad)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...HCwrap,
      display: "grid",
      gridTemplateColumns: "1fr 1.2fr",
      gap: 64,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "Contact",
    title: "Request a Bid",
    lead: "Tell us about your project. We respond to every request within two business days."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 36,
      font: "15px/2.1 var(--font-sans)",
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--text-heading)"
    }
  }, "Huffman Corporation"), /*#__PURE__*/React.createElement("br", null), "Bridgeport, West Virginia", /*#__PURE__*/React.createElement("br", null), "(304) 555-0134", /*#__PURE__*/React.createElement("br", null), "office@huffmancorp.example")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-card)",
      padding: 32
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "48px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 26px var(--font-serif-display)",
      color: "var(--text-heading)"
    }
  }, "Request Received"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "15px var(--font-sans)",
      color: "var(--text-body)",
      margin: "12px 0 24px"
    }
  }, "Thank you. We will be in touch within two business days."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => setSent(false)
  }, "Send Another")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Full Name",
    placeholder: "Jane Smith"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Phone",
    placeholder: "(304) 555-0100"
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    type: "email",
    placeholder: "jane@company.com"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Project Type",
    placeholder: "Select one\u2026",
    options: ["Commercial", "Residential", "Institutional", "Specialty"]
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "Project Details",
    rows: 4,
    hint: "Location, scope, and timeline help us respond faster."
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Request a call back"
  }), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    onClick: () => setSent(true)
  }, "Submit Request"))))));
}
function HomePage({
  onNav
}) {
  return /*#__PURE__*/React.createElement("div", {
    "data-screen-label": "Home page"
  }, /*#__PURE__*/React.createElement(HCHero, {
    onNav: onNav
  }), /*#__PURE__*/React.createElement(HCServices, null), /*#__PURE__*/React.createElement(HCProjectsTeaser, {
    onNav: onNav
  }), /*#__PURE__*/React.createElement(HCStatsBand, null), /*#__PURE__*/React.createElement(HCClients, null));
}
function App() {
  const [page, setPage] = React.useState("Home");
  const nav = p => {
    setPage(p);
    window.scrollTo(0, 0);
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(HCHeader, {
    page: page,
    onNav: nav
  }), page === "Home" && /*#__PURE__*/React.createElement(HomePage, {
    onNav: nav
  }), page === "Projects" && /*#__PURE__*/React.createElement(ProjectsPage, null), page === "Services" && /*#__PURE__*/React.createElement(ServicesPage, null), page === "About" && /*#__PURE__*/React.createElement(AboutPage, null), page === "Contact" && /*#__PURE__*/React.createElement(ContactPage, null), /*#__PURE__*/React.createElement(HCFooter, {
    onNav: nav
  }));
}
Object.assign(window, {
  HCApp: App
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/pages.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/sections.jsx
try { (() => {
// Huffman Corporation marketing-site sections. Consumes DS components from the bundle namespace.
const DS = window.HuffmanConstructionDesignSystem_a62619;
const {
  Button,
  Input,
  Select,
  Textarea,
  Checkbox,
  Card,
  Badge,
  Stat,
  SectionHeading,
  Tabs
} = DS;
const wrap = {
  maxWidth: "var(--container-max)",
  margin: "0 auto",
  padding: "0 32px"
};
function Header({
  page,
  onNav
}) {
  const links = ["Home", "Projects", "Services", "About", "Contact"];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      background: "#fff",
      borderBottom: "1px solid var(--border-default)",
      position: "sticky",
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      height: 76
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#home",
    onClick: e => {
      e.preventDefault();
      onNav("Home");
    },
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      textDecoration: "none"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/hc-mark.png",
    alt: "HC",
    width: "44",
    height: "44"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "var(--font-serif-display)",
      fontWeight: 700,
      fontSize: 21,
      lineHeight: 1.1,
      color: "var(--hc-blue-700)"
    }
  }, "Huffman Corporation"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      font: "italic 600 10.5px var(--font-serif-display)",
      letterSpacing: "0.04em",
      color: "var(--hc-blue-600)"
    }
  }, "General Contractors \xB7 Construction Managers"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 26
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#" + l.toLowerCase(),
    onClick: e => {
      e.preventDefault();
      onNav(l);
    },
    style: {
      font: `${page === l ? 600 : 500} 15px var(--font-sans)`,
      color: page === l ? "var(--hc-blue-700)" : "var(--text-body)",
      textDecoration: "none",
      borderBottom: page === l ? "2px solid var(--brand)" : "2px solid transparent",
      paddingBottom: 4
    }
  }, l)), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: () => onNav("Contact")
  }, "Request a Bid"))));
}
function PhotoPlaceholder({
  label = "Project Photography",
  height = 320,
  dark = false,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height,
      background: dark ? "var(--hc-blue-800)" : "var(--hc-gray-200)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: dark ? "var(--text-on-dark-muted)" : "var(--hc-gray-500)",
      font: "600 12px var(--font-sans)",
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      ...style
    }
  }, label);
}
function Hero({
  onNav
}) {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Hero",
    style: {
      position: "relative",
      background: "var(--hc-blue-900)"
    }
  }, /*#__PURE__*/React.createElement(PhotoPlaceholder, {
    label: "Full-bleed jobsite photo",
    height: 520,
    dark: true,
    style: {
      position: "absolute",
      inset: 0,
      height: "100%"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "rgba(13,44,80,0.55)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      position: "relative",
      padding: "110px 32px 120px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 13px var(--font-sans)",
      letterSpacing: "var(--tracking-kicker)",
      textTransform: "uppercase",
      color: "var(--hc-blue-400)"
    }
  }, "Bridgeport, West Virginia \xB7 Since 1988"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "700 56px/1.08 var(--font-serif-display)",
      letterSpacing: "-0.01em",
      color: "#fff",
      maxWidth: 640,
      margin: "18px 0 0"
    }
  }, "Built on Reputation."), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "19px/1.55 var(--font-sans)",
      color: "rgba(255,255,255,0.85)",
      maxWidth: 560,
      margin: "20px 0 32px"
    }
  }, "For nearly four decades, Huffman Corporation has delivered commercial, institutional, and residential projects across North Central West Virginia \u2014 most of them for clients who came back."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    onClick: () => onNav("Contact")
  }, "Request a Bid"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "onDark",
    onClick: () => onNav("Projects")
  }, "View Our Work"))));
}
const SERVICES = [{
  name: "Commercial",
  desc: "Offices, retail, and light industrial — ground-up construction and renovations for regional businesses."
}, {
  name: "Institutional",
  desc: "Schools, healthcare, and municipal facilities delivered on public timelines and budgets."
}, {
  name: "Residential",
  desc: "Custom homes and residential developments built to last generations."
}, {
  name: "Specialty",
  desc: "Complex and unconventional scopes other contractors pass on."
}];
function Services() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Services",
    style: {
      padding: "var(--section-pad) 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: wrap
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "What We Build",
    title: "Four Divisions, One Standard"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 24,
      marginTop: 48
    }
  }, SERVICES.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.name,
    style: {
      borderTop: "3px solid var(--brand)",
      background: "var(--surface-subtle)",
      padding: "24px 22px 26px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 21px var(--font-serif-display)",
      color: "var(--text-heading)"
    }
  }, s.name), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "14.5px/1.6 var(--font-sans)",
      color: "var(--text-body)",
      margin: "10px 0 0"
    }
  }, s.desc))))));
}
const PROJECTS = [{
  title: "Bridgeport Middle School Addition",
  cat: "Institutional",
  year: "2024",
  desc: "22,000 sq ft classroom wing completed while school remained in session."
}, {
  title: "Meadowbrook Commerce Center",
  cat: "Commercial",
  year: "2023",
  desc: "Three-tenant retail and office shell with full sitework."
}, {
  title: "Simpson Creek Residence",
  cat: "Residential",
  year: "2024",
  desc: "Custom 4,200 sq ft home on a hillside site."
}, {
  title: "Regional Clinic Renovation",
  cat: "Institutional",
  year: "2022",
  desc: "Phased occupied renovation of an outpatient facility."
}, {
  title: "Route 50 Warehouse",
  cat: "Commercial",
  year: "2023",
  desc: "40,000 sq ft pre-engineered warehouse and yard."
}, {
  title: "Historic Storefront Restoration",
  cat: "Specialty",
  year: "2021",
  desc: "Facade restoration and structural repair downtown."
}];
function ProjectGrid({
  limit,
  filter
}) {
  let list = PROJECTS;
  if (filter && filter !== "All Projects") list = list.filter(p => p.cat === filter);
  if (limit) list = list.slice(0, limit);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 28
    }
  }, list.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.title,
    imageLabel: "Project Photo",
    meta: p.cat,
    title: p.title,
    lifted: true
  }, p.desc, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral",
    outline: true
  }, "Completed ", p.year)))));
}
function ProjectsTeaser({
  onNav
}) {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Projects teaser",
    style: {
      padding: "var(--section-pad) 0",
      background: "var(--surface-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      marginBottom: 48
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "Our Work",
    title: "Recent Projects"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => onNav("Projects")
  }, "All Projects")), /*#__PURE__*/React.createElement(ProjectGrid, {
    limit: 3
  })));
}
function StatsBand() {
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Stats band",
    style: {
      background: "var(--surface-dark)",
      padding: "72px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "38",
    label: "Years in Business",
    onDark: true
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "500+",
    label: "Projects Completed",
    onDark: true
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "80%",
    label: "Repeat Clients",
    onDark: true
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "4",
    label: "Construction Divisions",
    onDark: true
  })));
}
function Clients() {
  const names = ["Harrison County Schools", "United Hospital Center", "City of Bridgeport", "WesBanco", "Meadowbrook Mall", "Dominion Energy"];
  return /*#__PURE__*/React.createElement("section", {
    "data-screen-label": "Clients",
    style: {
      padding: "72px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 12.5px var(--font-sans)",
      letterSpacing: "var(--tracking-kicker)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 32
    }
  }, "Trusted by clients across the region"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      gap: 48,
      flexWrap: "wrap"
    }
  }, names.map(n => /*#__PURE__*/React.createElement("span", {
    key: n,
    style: {
      font: "700 17px var(--font-serif-display)",
      color: "var(--hc-gray-300)",
      whiteSpace: "nowrap"
    }
  }, n))), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "12px var(--font-sans)",
      color: "var(--hc-gray-300)",
      marginTop: 28
    }
  }, "Client names shown as monotone placeholders \u2014 replace with monotone client logos.")));
}
function Footer({
  onNav
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--surface-dark)",
      padding: "56px 0 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: "grid",
      gridTemplateColumns: "2fr 1fr 1fr",
      gap: 48
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 22px var(--font-serif-display)",
      color: "#fff"
    }
  }, "Huffman Corporation"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "italic 600 12px var(--font-serif-display)",
      color: "var(--hc-blue-400)",
      marginTop: 4
    }
  }, "General Contractors \xB7 Construction Managers"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "14px/1.7 var(--font-sans)",
      color: "var(--text-on-dark-muted)",
      maxWidth: 340,
      marginTop: 16
    }
  }, "Serving North Central West Virginia since 1988. Licensed, bonded, and insured.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 12.5px var(--font-sans)",
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--hc-blue-400)",
      marginBottom: 14
    }
  }, "Company"), ["Projects", "Services", "About", "Contact"].map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#" + l.toLowerCase(),
    onClick: e => {
      e.preventDefault();
      onNav(l);
    },
    style: {
      display: "block",
      font: "14px var(--font-sans)",
      color: "rgba(255,255,255,0.85)",
      textDecoration: "none",
      padding: "5px 0"
    }
  }, l))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 12.5px var(--font-sans)",
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--hc-blue-400)",
      marginBottom: 14
    }
  }, "Contact"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "14px/2 var(--font-sans)",
      color: "rgba(255,255,255,0.85)"
    }
  }, "Bridgeport, West Virginia", /*#__PURE__*/React.createElement("br", null), "(304) 555-0134", /*#__PURE__*/React.createElement("br", null), "office@huffmancorp.example"))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      borderTop: "1px solid rgba(255,255,255,0.14)",
      marginTop: 44,
      paddingTop: 22,
      font: "12.5px var(--font-sans)",
      color: "rgba(255,255,255,0.5)"
    }
  }, "\xA9 2026 Huffman Corporation. Wayne Huffman, Owner."));
}
Object.assign(window, {
  HCHeader: Header,
  HCHero: Hero,
  HCServices: Services,
  HCProjectGrid: ProjectGrid,
  HCProjectsTeaser: ProjectsTeaser,
  HCStatsBand: StatsBand,
  HCClients: Clients,
  HCFooter: Footer,
  HCPhotoPlaceholder: PhotoPlaceholder,
  HCwrap: wrap
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/sections.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
