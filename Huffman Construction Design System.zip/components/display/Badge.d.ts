/** Small uppercase label for project categories and statuses. */
export interface BadgeProps {
  tone?: "brand" | "navy" | "neutral" | "success" | "warning" | "danger";
  outline?: boolean;
  children?: React.ReactNode;
}
export declare function Badge(props: BadgeProps): JSX.Element;
