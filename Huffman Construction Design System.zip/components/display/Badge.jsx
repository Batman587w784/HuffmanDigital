import React from "react";

/** Small squared label. tone: brand | navy | neutral | success | warning | danger. outline for bordered style. */
export function Badge({ tone = "brand", outline = false, children, style }) {
  const tones = {
    brand: ["var(--hc-blue-600)", "var(--hc-blue-50)", "var(--hc-blue-700)"],
    navy: ["var(--hc-blue-900)", "#e8edf4", "var(--hc-blue-900)"],
    neutral: ["var(--hc-gray-500)", "var(--hc-gray-100)", "var(--hc-gray-700)"],
    success: ["var(--hc-success)", "#e7f2ea", "var(--hc-success)"],
    warning: ["var(--hc-warning)", "#f6eddd", "var(--hc-warning)"],
    danger: ["var(--hc-danger)", "#f6e7e7", "var(--hc-danger)"],
  };
  const [solid, tint, text] = tones[tone] || tones.brand;
  return (
    <span
      style={{
        display: "inline-block",
        fontFamily: "var(--font-sans)",
        fontSize: 12,
        fontWeight: 600,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        padding: "4px 10px",
        borderRadius: "var(--radius-sm)",
        background: outline ? "transparent" : tint,
        color: text,
        border: outline ? `1px solid ${solid}` : "1px solid transparent",
        ...style,
      }}
    >
      {children}
    </span>
  );
}
