Small uppercase squared label for project categories ("COMMERCIAL") and statuses ("COMPLETED 2024").

```jsx
<Badge>Commercial</Badge>
<Badge tone="neutral" outline>Completed 2024</Badge>
```
