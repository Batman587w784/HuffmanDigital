/**
 * White bordered card with optional flush photo header — the project-card pattern.
 * @startingPoint section="Display" subtitle="Photo-forward project card" viewport="700x330"
 */
export interface CardProps {
  /** Image URL for the flush header */
  image?: string;
  /** Placeholder label when no image is available */
  imageLabel?: string;
  /** Uppercase kicker above the title */
  meta?: string;
  title?: string;
  /** Adds --shadow-card */
  lifted?: boolean;
  children?: React.ReactNode;
}
export declare function Card(props: CardProps): JSX.Element;
