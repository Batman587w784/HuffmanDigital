import React from "react";

/** White card. If image/imageLabel given, renders a flush photo (or placeholder) header. */
export function Card({ image, imageLabel, title, meta, children, lifted = false, style }) {
  return (
    <div
      style={{
        background: "var(--surface-card)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-md)",
        boxShadow: lifted ? "var(--shadow-card)" : "none",
        overflow: "hidden",
        fontFamily: "var(--font-sans)",
        ...style,
      }}
    >
      {(image || imageLabel) && (
        <div
          style={{
            height: 180,
            background: image
              ? `url(${image}) center/cover no-repeat`
              : "var(--hc-gray-200)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "var(--hc-gray-500)",
            fontSize: 13,
            letterSpacing: "0.06em",
            textTransform: "uppercase",
          }}
        >
          {!image && (imageLabel || "Photo")}
        </div>
      )}
      <div style={{ padding: "18px 20px 20px" }}>
        {meta && (
          <div style={{ fontSize: 12.5, fontWeight: 600, letterSpacing: "var(--tracking-kicker)", textTransform: "uppercase", color: "var(--brand)", marginBottom: 6 }}>
            {meta}
          </div>
        )}
        {title && (
          <div style={{ fontFamily: "var(--font-serif-display)", fontWeight: 700, fontSize: 20, color: "var(--text-heading)", lineHeight: 1.25, marginBottom: children ? 8 : 0 }}>
            {title}
          </div>
        )}
        {children && <div style={{ fontSize: 14.5, lineHeight: 1.55, color: "var(--text-body)" }}>{children}</div>}
      </div>
    </div>
  );
}
