White bordered card with flush photo header — the standard project-card pattern for photo-forward sections.

```jsx
<Card imageLabel="Project Photo" meta="Institutional" title="Bridgeport Middle School Addition">
  22,000 sq ft classroom wing, completed 2024.
</Card>
```

Use `image` with a real photo URL when available; `imageLabel` renders a gray placeholder. `lifted` adds the card shadow.
