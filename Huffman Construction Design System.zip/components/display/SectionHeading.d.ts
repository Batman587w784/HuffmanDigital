/** Kicker + serif heading + 3px brand rule — the signature section-opening motif. */
export interface SectionHeadingProps {
  /** Uppercase eyebrow, e.g. "Our Work" */
  kicker?: string;
  title: string;
  /** Optional lead paragraph below the rule */
  lead?: string;
  align?: "left" | "center";
  onDark?: boolean;
}
export declare function SectionHeading(props: SectionHeadingProps): JSX.Element;
