import React from "react";

/** Signature section heading: uppercase kicker, serif heading, 3px brand rule. align: left | center. */
export function SectionHeading({ kicker, title, lead, align = "left", onDark = false, style }) {
  const center = align === "center";
  return (
    <div style={{ textAlign: center ? "center" : "left", fontFamily: "var(--font-sans)", ...style }}>
      {kicker && (
        <div style={{ fontSize: 12.5, fontWeight: 600, letterSpacing: "var(--tracking-kicker)", textTransform: "uppercase", color: onDark ? "var(--hc-blue-400)" : "var(--brand)" }}>
          {kicker}
        </div>
      )}
      <h2
        style={{
          fontFamily: "var(--font-serif-display)",
          fontWeight: 700,
          fontSize: "var(--text-h2)",
          lineHeight: "var(--leading-heading)",
          letterSpacing: "var(--tracking-display)",
          color: onDark ? "#fff" : "var(--text-heading)",
          margin: kicker ? "10px 0 0" : 0,
        }}
      >
        {title}
      </h2>
      <div
        style={{
          width: 56,
          height: "var(--rule-w)",
          background: "var(--brand)",
          margin: center ? "16px auto 0" : "16px 0 0",
        }}
      ></div>
      {lead && (
        <p style={{ fontSize: "var(--text-lead)", lineHeight: 1.55, color: onDark ? "var(--text-on-dark-muted)" : "var(--text-body)", maxWidth: 640, margin: center ? "18px auto 0" : "18px 0 0" }}>
          {lead}
        </p>
      )}
    </div>
  );
}
