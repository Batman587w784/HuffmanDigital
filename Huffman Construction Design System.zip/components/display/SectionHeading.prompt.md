Opens every page section: uppercase kicker, bold serif heading, short 3px brand rule, optional lead.

```jsx
<SectionHeading kicker="Our Work" title="Projects Across North Central West Virginia"
  lead="Commercial, institutional, and residential — most for repeat clients." />
```

Use `align="center"` for standalone bands, `onDark` on navy surfaces.
