/** Big serif number with uppercase label — proof-over-promise stat blocks. */
export interface StatProps {
  /** e.g. "38", "500+" */
  value: string;
  /** e.g. "Years in Business" */
  label: string;
  /** White text for navy bands */
  onDark?: boolean;
}
export declare function Stat(props: StatProps): JSX.Element;
