import React from "react";

/** Big serif number + label. onDark for navy stat bands. */
export function Stat({ value, label, onDark = false, style }) {
  return (
    <div style={{ fontFamily: "var(--font-sans)", ...style }}>
      <div
        style={{
          fontFamily: "var(--font-serif-display)",
          fontWeight: 700,
          fontSize: 48,
          lineHeight: 1.05,
          letterSpacing: "-0.01em",
          color: onDark ? "#fff" : "var(--text-heading)",
        }}
      >
        {value}
      </div>
      <div
        style={{
          marginTop: 6,
          fontSize: 13,
          fontWeight: 600,
          letterSpacing: "var(--tracking-kicker)",
          textTransform: "uppercase",
          color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)",
        }}
      >
        {label}
      </div>
    </div>
  );
}
