Big serif number + uppercase label; the proof-over-promise stat block ("38 Years in Business"). Usually 3–4 in a row on a navy band with `onDark`.

```jsx
<Stat value="38" label="Years in Business" onDark />
<Stat value="500+" label="Projects Completed" onDark />
```
