/**
 * Primary action button. Serious, squared-off (4px radius), brand blue.
 * @startingPoint section="Forms" subtitle="Primary, secondary, ghost, onDark" viewport="700x180"
 */
export interface ButtonProps {
  /** Visual style */
  variant?: "primary" | "secondary" | "ghost" | "onDark";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  children?: React.ReactNode;
  onClick?: () => void;
}
export declare function Button(props: ButtonProps): JSX.Element;
