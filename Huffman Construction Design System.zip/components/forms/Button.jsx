import React from "react";

/** Huffman button. variant: primary | secondary | ghost | onDark. size: sm | md | lg */
export function Button({ variant = "primary", size = "md", disabled = false, children, style, ...rest }) {
  const [state, setState] = React.useState("rest"); // rest | hover | press
  const sizes = {
    sm: { padding: "8px 16px", fontSize: 13.5 },
    md: { padding: "11px 22px", fontSize: 15 },
    lg: { padding: "14px 30px", fontSize: 16 },
  };
  const palettes = {
    primary: {
      rest: { background: "var(--hc-blue-600)", color: "#fff", border: "1px solid transparent" },
      hover: { background: "var(--hc-blue-700)" },
      press: { background: "var(--hc-blue-800)" },
    },
    secondary: {
      rest: { background: "#fff", color: "var(--hc-blue-700)", border: "1px solid var(--hc-blue-600)" },
      hover: { background: "var(--hc-blue-50)" },
      press: { background: "var(--hc-blue-100)" },
    },
    ghost: {
      rest: { background: "transparent", color: "var(--hc-blue-700)", border: "1px solid transparent" },
      hover: { background: "var(--hc-blue-50)" },
      press: { background: "var(--hc-blue-100)" },
    },
    onDark: {
      rest: { background: "#fff", color: "var(--hc-blue-800)", border: "1px solid transparent" },
      hover: { background: "var(--hc-blue-50)" },
      press: { background: "var(--hc-blue-100)" },
    },
  };
  const p = palettes[variant] || palettes.primary;
  const merged = {
    fontFamily: "var(--font-sans)",
    fontWeight: 600,
    letterSpacing: "0.01em",
    borderRadius: "var(--radius-md)",
    cursor: disabled ? "not-allowed" : "pointer",
    transition: "background var(--duration-fast) var(--ease-standard), color var(--duration-fast) var(--ease-standard)",
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    ...sizes[size],
    ...p.rest,
    ...(state === "hover" && !disabled ? p.hover : null),
    ...(state === "press" && !disabled ? p.press : null),
    ...(disabled ? { background: "var(--hc-gray-200)", color: "var(--hc-gray-500)", border: "1px solid transparent" } : null),
    ...style,
  };
  return (
    <button
      type="button"
      disabled={disabled}
      style={merged}
      onMouseEnter={() => setState("hover")}
      onMouseLeave={() => setState("rest")}
      onMouseDown={() => setState("press")}
      onMouseUp={() => setState("hover")}
      {...rest}
    >
      {children}
    </button>
  );
}
