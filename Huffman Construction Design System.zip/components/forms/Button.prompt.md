Squared-off brand-blue button for primary site actions ("Request a Bid", "View Projects"); hover darkens one ramp step, never scales.

```jsx
<Button variant="primary" size="lg">Request a Bid</Button>
<Button variant="secondary">View Projects</Button>
```

Variants: `primary` (blue-600), `secondary` (white + blue border), `ghost` (text only), `onDark` (white fill, for navy sections). Sizes sm/md/lg. No icons required; keep labels ≤ 3 words, Title Case.
