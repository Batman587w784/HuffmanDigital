import React from "react";

/** Square checkbox with label. Controlled or uncontrolled. */
export function Checkbox({ label, checked, defaultChecked = false, onChange, disabled = false, style }) {
  const [internal, setInternal] = React.useState(defaultChecked);
  const isOn = checked !== undefined ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    if (checked === undefined) setInternal(!isOn);
    onChange && onChange(!isOn);
  };
  return (
    <label
      onClick={toggle}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 10,
        cursor: disabled ? "not-allowed" : "pointer",
        fontFamily: "var(--font-sans)",
        fontSize: 15,
        color: disabled ? "var(--text-muted)" : "var(--text-body)",
        userSelect: "none",
        ...style,
      }}
    >
      <span
        style={{
          width: 18,
          height: 18,
          flex: "none",
          borderRadius: "var(--radius-sm)",
          border: `1px solid ${isOn ? "var(--hc-blue-600)" : "var(--border-strong)"}`,
          background: disabled ? "var(--hc-gray-100)" : isOn ? "var(--hc-blue-600)" : "#fff",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          transition: "background var(--duration-fast) var(--ease-standard)",
        }}
      >
        {isOn && (
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
            <path d="M2 6.2 4.8 9 10 3.4" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </span>
      {label}
    </label>
  );
}
