Square brand-blue checkbox with label, for form opt-ins and filters.

```jsx
<Checkbox label="Request a call back" defaultChecked />
<Checkbox label="Unavailable option" disabled />
```
