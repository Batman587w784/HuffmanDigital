/** Labeled text input with hint/error states. Also exports Textarea. */
export interface InputProps {
  label?: string;
  hint?: string;
  error?: string;
  type?: string;
  placeholder?: string;
  value?: string;
  onChange?: (e: any) => void;
}
export declare function Input(props: InputProps): JSX.Element;
export declare function Textarea(props: InputProps & { rows?: number }): JSX.Element;
