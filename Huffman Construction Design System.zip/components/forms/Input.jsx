import React from "react";

/** Labeled text input. */
export function Input({ label, hint, error, type = "text", placeholder, value, onChange, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <label style={{ display: "block", fontFamily: "var(--font-sans)", ...style }}>
      {label && (
        <span style={{ display: "block", fontSize: 14, fontWeight: 600, color: "var(--text-heading)", marginBottom: 6 }}>
          {label}
        </span>
      )}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          width: "100%",
          boxSizing: "border-box",
          fontFamily: "var(--font-sans)",
          fontSize: 15,
          color: "var(--text-body)",
          padding: "11px 12px",
          background: "#fff",
          border: `1px solid ${error ? "var(--hc-danger)" : focus ? "var(--hc-blue-600)" : "var(--border-strong)"}`,
          borderRadius: "var(--radius-sm)",
          outline: "none",
          boxShadow: focus ? "var(--focus-ring)" : "none",
          transition: "box-shadow var(--duration-fast) var(--ease-standard)",
        }}
        {...rest}
      />
      {(error || hint) && (
        <span style={{ display: "block", fontSize: 12.5, marginTop: 5, color: error ? "var(--hc-danger)" : "var(--text-muted)" }}>
          {error || hint}
        </span>
      )}
    </label>
  );
}

/** Multiline variant sharing the same styling. */
export function Textarea({ label, hint, error, placeholder, value, onChange, rows = 4, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <label style={{ display: "block", fontFamily: "var(--font-sans)", ...style }}>
      {label && (
        <span style={{ display: "block", fontSize: 14, fontWeight: 600, color: "var(--text-heading)", marginBottom: 6 }}>
          {label}
        </span>
      )}
      <textarea
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        rows={rows}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          width: "100%",
          boxSizing: "border-box",
          fontFamily: "var(--font-sans)",
          fontSize: 15,
          color: "var(--text-body)",
          padding: "11px 12px",
          background: "#fff",
          border: `1px solid ${error ? "var(--hc-danger)" : focus ? "var(--hc-blue-600)" : "var(--border-strong)"}`,
          borderRadius: "var(--radius-sm)",
          outline: "none",
          resize: "vertical",
          boxShadow: focus ? "var(--focus-ring)" : "none",
        }}
        {...rest}
      />
      {(error || hint) && (
        <span style={{ display: "block", fontSize: 12.5, marginTop: 5, color: error ? "var(--hc-danger)" : "var(--text-muted)" }}>
          {error || hint}
        </span>
      )}
    </label>
  );
}
