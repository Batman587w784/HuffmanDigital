Labeled text input (and Textarea) for the contact/bid-request form; 2px radius, blue focus ring, muted hint or red error line below.

```jsx
<Input label="Full Name" placeholder="Jane Smith" />
<Input label="Email" error="Enter a valid email address." />
<Textarea label="Project Details" rows={4} hint="Location, scope, and timeline help us respond faster." />
```
