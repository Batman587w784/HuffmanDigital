/** Labeled native select, styled to match Input. */
export interface SelectProps {
  label?: string;
  hint?: string;
  options?: Array<string | { value: string; label: string }>;
  value?: string;
  onChange?: (e: any) => void;
  placeholder?: string;
}
export declare function Select(props: SelectProps): JSX.Element;
