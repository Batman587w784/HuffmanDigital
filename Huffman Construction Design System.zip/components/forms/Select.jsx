import React from "react";

/** Labeled native select. options: [{value,label}] or ["a","b"]. */
export function Select({ label, hint, options = [], value, onChange, placeholder, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const opts = options.map((o) => (typeof o === "string" ? { value: o, label: o } : o));
  return (
    <label style={{ display: "block", fontFamily: "var(--font-sans)", ...style }}>
      {label && (
        <span style={{ display: "block", fontSize: 14, fontWeight: 600, color: "var(--text-heading)", marginBottom: 6 }}>
          {label}
        </span>
      )}
      <select
        value={value}
        onChange={onChange}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          width: "100%",
          boxSizing: "border-box",
          fontFamily: "var(--font-sans)",
          fontSize: 15,
          color: "var(--text-body)",
          padding: "11px 12px",
          background: "#fff",
          border: `1px solid ${focus ? "var(--hc-blue-600)" : "var(--border-strong)"}`,
          borderRadius: "var(--radius-sm)",
          outline: "none",
          boxShadow: focus ? "var(--focus-ring)" : "none",
        }}
        {...rest}
      >
        {placeholder && <option value="">{placeholder}</option>}
        {opts.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
      {hint && <span style={{ display: "block", fontSize: 12.5, marginTop: 5, color: "var(--text-muted)" }}>{hint}</span>}
    </label>
  );
}
