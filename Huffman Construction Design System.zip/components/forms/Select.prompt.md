Labeled native select matching Input styling; used for project-type pickers on the bid-request form.

```jsx
<Select label="Project Type" placeholder="Select one…"
  options={["Commercial", "Residential", "Institutional", "Specialty"]} />
```
