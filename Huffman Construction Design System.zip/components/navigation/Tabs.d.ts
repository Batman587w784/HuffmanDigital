/** Underline tabs with 3px brand-rule indicator — project category filters. */
export interface TabsProps {
  items: string[];
  active?: number;
  defaultActive?: number;
  onChange?: (index: number) => void;
}
export declare function Tabs(props: TabsProps): JSX.Element;
