import React from "react";

/** Underline tabs. items: string[]. Controlled (active/onChange) or uncontrolled. */
export function Tabs({ items = [], active, defaultActive = 0, onChange, style }) {
  const [internal, setInternal] = React.useState(defaultActive);
  const idx = active !== undefined ? active : internal;
  const [hover, setHover] = React.useState(-1);
  return (
    <div style={{ display: "flex", gap: 28, borderBottom: "1px solid var(--border-default)", fontFamily: "var(--font-sans)", ...style }}>
      {items.map((item, i) => {
        const on = i === idx;
        return (
          <button
            key={item}
            type="button"
            onClick={() => { if (active === undefined) setInternal(i); onChange && onChange(i); }}
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(-1)}
            style={{
              background: "none",
              border: "none",
              padding: "10px 2px 12px",
              marginBottom: -1,
              cursor: "pointer",
              fontFamily: "var(--font-sans)",
              fontSize: 15,
              fontWeight: on ? 600 : 500,
              color: on ? "var(--hc-blue-700)" : hover === i ? "var(--hc-blue-600)" : "var(--text-muted)",
              borderBottom: `3px solid ${on ? "var(--brand)" : "transparent"}`,
              transition: "color var(--duration-fast) var(--ease-standard)",
            }}
          >
            {item}
          </button>
        );
      })}
    </div>
  );
}
