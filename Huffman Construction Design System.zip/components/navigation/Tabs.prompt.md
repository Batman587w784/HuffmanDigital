Underline tabs whose active indicator is the 3px brand rule; used as project-category filters.

```jsx
<Tabs items={["All", "Commercial", "Institutional", "Residential", "Specialty"]}
  onChange={(i) => setFilter(i)} />
```
