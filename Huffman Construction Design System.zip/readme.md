# Huffman Professional Construction System

Design system for **Huffman Corporation** — a general contractor based in Bridgeport, West Virginia, serving North Central West Virginia for nearly four decades. Commercial, residential, institutional, and specialty construction. Led by owner Wayne Huffman. Reputation built on word of mouth, repeat clients, and long-term relationships.

A clean, navy-and-white visual system: professional, grounded, high-trust. Strong serif typography, restrained copy, polished spacing, monotone client logos, photo-forward project sections. Decades of credibility, communicated without overstatement.

**Sources provided:** company blurb + two logo images (`uploads/`). No codebase, Figma, fonts, or photography were provided — see Caveats.

## Content fundamentals

- **Voice:** third-person and first-person-plural ("Huffman Corporation has served…", "We build…"). Never "I". Plain, declarative statements. No hype adjectives, no exclamation points, no emoji.
- **Casing:** Title Case for headings and nav; sentence case for body. Uppercase reserved for small kickers/eyebrows ("COMMERCIAL · INSTITUTIONAL · RESIDENTIAL").
- **Copy length:** short. Headlines ≤ 8 words. Body paragraphs 1–3 sentences. Let numbers and project names carry the weight ("38 years", "500+ projects completed").
- **Proof over promise:** cite tenure, repeat clients, named projects, and locations instead of superlatives. "Serving North Central West Virginia since 1988" beats "the best contractor in the region".
- Example headline: *Built on Reputation.* Example body: *For nearly four decades, Huffman Corporation has delivered commercial, institutional, and residential projects across North Central West Virginia — most of them for clients who came back.*

## Visual foundations

- **Color:** white pages, navy ink. Brand blue `#0252b3` (sampled from logo mark) for actions and accents; deep navy `#0d2c50` for dark sections and footers. One accent color only — no secondary hues. Semantic green/amber/red exist for forms only.
- **Type:** serif display (`Tinos`, standing in for the Times-style logo serif) bold for all headings; `Public Sans` for body/UI. Uppercase letterspaced kickers (0.14em) above headings. Hero up to 56px.
- **Spacing:** 4px base scale; generous 96px section rhythm; 1160px max container. Whitespace is the primary luxury cue.
- **Corners:** near-square — 2–6px radii. Architectural, not friendly-rounded.
- **Borders & rules:** 1px hairline `--border-default`; a short 3px brand-blue rule under section headings is the signature motif.
- **Shadows:** one restrained card shadow (`--shadow-card`); a slightly stronger `--shadow-raised` for dialogs. No glows, no colored shadows.
- **Backgrounds:** flat white, light gray `#f7f8fa`, pale blue tint `#eef4fb`, or solid navy. **No gradients, no patterns, no illustrations.** Full-bleed project photography is the only decoration; on dark photo sections use a navy scrim (`rgba(13,44,80,.55)`) for text protection.
- **Imagery:** photo-forward project sections; real jobsite/building photography, neutral-to-cool grade. Client logos rendered monotone (grayscale or single navy). *No photography was provided — kits use labeled placeholder blocks.*
- **Motion:** minimal. 120–200ms ease (`--ease-standard`) on hover/focus only; no entrance animations, no bounces.
- **Hover:** darken (blue-600 → blue-700), or underline for links. **Press:** darken one more step; no scale effects. **Focus:** 3px soft blue ring (`--focus-ring`).
- **Transparency/blur:** none, except the photo scrim above.
- **Cards:** white, 1px border, 4px radius, optional `--shadow-card`; flush-square photos at top.

## Iconography

- No icon assets were provided and no icon system exists in the sources. Kits and components use **Lucide** (CDN, 1.75px stroke) as a flagged substitution — its plain engineering-drawing stroke style fits the brand. Use sparingly: contact rows, list bullets, UI chrome. Never emoji, never decorative icon grids.
- Logos in `assets/`: `hc-mark.png` (blue square HC monogram, cropped from upload) and `huffman-lockup.png` (full lockup + "General Contractors / Construction Managers" tagline; checkerboard background flattened to white — **not transparent**, use on white only).

## Index

- `styles.css` — global entry; imports everything in `tokens/`
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css`, `base.css`
- `assets/` — `hc-mark.png`, `huffman-lockup.png`
- `guidelines/` — foundation specimen cards (colors, type, spacing, brand)
- `components/forms/` — Button, Input, Select, Checkbox
- `components/display/` — Card, Badge, Stat, SectionHeading
- `components/navigation/` — Tabs
- `ui_kits/website/` — marketing-site kit: `index.html` (interactive home), plus section JSX
- `SKILL.md` — agent skill entry point

**Intentional additions** (no component source existed): `Stat` (tenure/project-count blocks — core to the proof-over-promise voice) and `SectionHeading` (kicker + serif heading + brand rule — the signature motif).

## Caveats

- Fonts are Google-Fonts substitutions (Tinos ≈ logo serif; Public Sans for UI). Provide real brand font files to replace `tokens/fonts.css`.
- Lockup PNG is white-flattened, not transparent. Provide an original vector/transparent logo if available.
- No photography or client logos provided; placeholders used throughout.
