# Website UI kit

Interactive recreation of the Huffman Corporation marketing site (no original site source was provided — this is an original design applying the brand system).

- `index.html` — entry; click-through: Home → Projects (filterable via Tabs) → Services → About → Contact (working fake bid-request form)
- `sections.jsx` — Header, Hero, Services, ProjectGrid, StatsBand, Clients, Footer, PhotoPlaceholder
- `pages.jsx` — page compositions + App router

All photography is placeholder blocks (none provided). Client logo row uses monotone text placeholders. Project names/stats are illustrative sample content — verify before publishing.
