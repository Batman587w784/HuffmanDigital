// Page-level views: Projects index, About, Contact (bid request).
const { Button, Input, Select, Textarea, Checkbox, Stat, SectionHeading, Tabs } = window.HuffmanConstructionDesignSystem_a62619;

function ProjectsPage() {
  const cats = ["All Projects", "Commercial", "Institutional", "Residential", "Specialty"];
  const [i, setI] = React.useState(0);
  return (
    <div data-screen-label="Projects page">
      <section style={{ padding: "72px 0 var(--section-pad)" }}>
        <div style={HCwrap}>
          <SectionHeading kicker="Our Work" title="Projects" lead="A selection of recent work across our four divisions. Most were built for repeat clients." />
          <div style={{ margin: "40px 0 36px" }}>
            <Tabs items={cats} active={i} onChange={setI} />
          </div>
          <HCProjectGrid filter={cats[i]} />
        </div>
      </section>
    </div>
  );
}

function ServicesPage() {
  return (
    <div data-screen-label="Services page">
      <HCServices />
      <HCStatsBand />
    </div>
  );
}

function AboutPage() {
  return (
    <div data-screen-label="About page">
      <section style={{ padding: "72px 0 var(--section-pad)" }}>
        <div style={{ ...HCwrap, display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 64, alignItems: "start" }}>
          <div>
            <SectionHeading kicker="About Us" title="Nearly Four Decades of Word-of-Mouth Work" />
            <p style={{ font: "16px/1.7 var(--font-sans)", color: "var(--text-body)", margin: "28px 0 0" }}>
              Huffman Corporation was established in Bridgeport, West Virginia, and has grown almost entirely by referral. We serve North Central West Virginia with commercial, residential, institutional, and specialty construction.
            </p>
            <p style={{ font: "16px/1.7 var(--font-sans)", color: "var(--text-body)", margin: "16px 0 0" }}>
              The company is led today by owner Wayne Huffman. Our clients come back because we deliver what we bid, on the schedule we committed to.
            </p>
            <div style={{ display: "flex", gap: 48, marginTop: 40 }}>
              <Stat value="1988" label="Established" />
              <Stat value="80%" label="Repeat Clients" />
            </div>
          </div>
          <HCPhotoPlaceholder label="Team / jobsite photo" height={420} />
        </div>
      </section>
    </div>
  );
}

function ContactPage() {
  const [sent, setSent] = React.useState(false);
  return (
    <div data-screen-label="Contact page">
      <section style={{ padding: "72px 0 var(--section-pad)" }}>
        <div style={{ ...HCwrap, display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 64, alignItems: "start" }}>
          <div>
            <SectionHeading kicker="Contact" title="Request a Bid" lead="Tell us about your project. We respond to every request within two business days." />
            <div style={{ marginTop: 36, font: "15px/2.1 var(--font-sans)", color: "var(--text-body)" }}>
              <strong style={{ color: "var(--text-heading)" }}>Huffman Corporation</strong><br />
              Bridgeport, West Virginia<br />
              (304) 555-0134<br />
              office@huffmancorp.example
            </div>
          </div>
          <div style={{ background: "#fff", border: "1px solid var(--border-default)", borderRadius: "var(--radius-md)", boxShadow: "var(--shadow-card)", padding: 32 }}>
            {sent ? (
              <div style={{ textAlign: "center", padding: "48px 0" }}>
                <div style={{ font: "700 26px var(--font-serif-display)", color: "var(--text-heading)" }}>Request Received</div>
                <p style={{ font: "15px var(--font-sans)", color: "var(--text-body)", margin: "12px 0 24px" }}>Thank you. We will be in touch within two business days.</p>
                <Button variant="secondary" onClick={() => setSent(false)}>Send Another</Button>
              </div>
            ) : (
              <div style={{ display: "grid", gap: 18 }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <Input label="Full Name" placeholder="Jane Smith" />
                  <Input label="Phone" placeholder="(304) 555-0100" />
                </div>
                <Input label="Email" type="email" placeholder="jane@company.com" />
                <Select label="Project Type" placeholder="Select one…" options={["Commercial", "Residential", "Institutional", "Specialty"]} />
                <Textarea label="Project Details" rows={4} hint="Location, scope, and timeline help us respond faster." />
                <Checkbox label="Request a call back" />
                <Button size="lg" onClick={() => setSent(true)}>Submit Request</Button>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

function HomePage({ onNav }) {
  return (
    <div data-screen-label="Home page">
      <HCHero onNav={onNav} />
      <HCServices />
      <HCProjectsTeaser onNav={onNav} />
      <HCStatsBand />
      <HCClients />
    </div>
  );
}

function App() {
  const [page, setPage] = React.useState("Home");
  const nav = (p) => { setPage(p); window.scrollTo(0, 0); };
  return (
    <div>
      <HCHeader page={page} onNav={nav} />
      {page === "Home" && <HomePage onNav={nav} />}
      {page === "Projects" && <ProjectsPage />}
      {page === "Services" && <ServicesPage />}
      {page === "About" && <AboutPage />}
      {page === "Contact" && <ContactPage />}
      <HCFooter onNav={nav} />
    </div>
  );
}

Object.assign(window, { HCApp: App });
