// Huffman Corporation marketing-site sections. Consumes DS components from the bundle namespace.
const DS = window.HuffmanConstructionDesignSystem_a62619;
const { Button, Input, Select, Textarea, Checkbox, Card, Badge, Stat, SectionHeading, Tabs } = DS;

const wrap = { maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 32px" };

function Header({ page, onNav }) {
  const links = ["Home", "Projects", "Services", "About", "Contact"];
  return (
    <header style={{ background: "#fff", borderBottom: "1px solid var(--border-default)", position: "sticky", top: 0, zIndex: 10 }}>
      <div style={{ ...wrap, display: "flex", alignItems: "center", justifyContent: "space-between", height: 76 }}>
        <a href="#home" onClick={(e) => { e.preventDefault(); onNav("Home"); }} style={{ display: "flex", alignItems: "center", gap: 14, textDecoration: "none" }}>
          <img src="../../assets/hc-mark.png" alt="HC" width="44" height="44" />
          <span style={{ display: "block" }}>
            <span style={{ display: "block", fontFamily: "var(--font-serif-display)", fontWeight: 700, fontSize: 21, lineHeight: 1.1, color: "var(--hc-blue-700)" }}>Huffman Corporation</span>
            <span style={{ display: "block", font: "italic 600 10.5px var(--font-serif-display)", letterSpacing: "0.04em", color: "var(--hc-blue-600)" }}>General Contractors · Construction Managers</span>
          </span>
        </a>
        <nav style={{ display: "flex", alignItems: "center", gap: 26 }}>
          {links.map((l) => (
            <a key={l} href={"#" + l.toLowerCase()} onClick={(e) => { e.preventDefault(); onNav(l); }}
              style={{ font: `${page === l ? 600 : 500} 15px var(--font-sans)`, color: page === l ? "var(--hc-blue-700)" : "var(--text-body)", textDecoration: "none", borderBottom: page === l ? "2px solid var(--brand)" : "2px solid transparent", paddingBottom: 4 }}>
              {l}
            </a>
          ))}
          <Button size="sm" onClick={() => onNav("Contact")}>Request a Bid</Button>
        </nav>
      </div>
    </header>
  );
}

function PhotoPlaceholder({ label = "Project Photography", height = 320, dark = false, style }) {
  return (
    <div style={{ height, background: dark ? "var(--hc-blue-800)" : "var(--hc-gray-200)", display: "flex", alignItems: "center", justifyContent: "center", color: dark ? "var(--text-on-dark-muted)" : "var(--hc-gray-500)", font: "600 12px var(--font-sans)", letterSpacing: "0.1em", textTransform: "uppercase", ...style }}>
      {label}
    </div>
  );
}

function Hero({ onNav }) {
  return (
    <section data-screen-label="Hero" style={{ position: "relative", background: "var(--hc-blue-900)" }}>
      <PhotoPlaceholder label="Full-bleed jobsite photo" height={520} dark style={{ position: "absolute", inset: 0, height: "100%" }} />
      <div style={{ position: "absolute", inset: 0, background: "rgba(13,44,80,0.55)" }}></div>
      <div style={{ ...wrap, position: "relative", padding: "110px 32px 120px" }}>
        <div style={{ font: "600 13px var(--font-sans)", letterSpacing: "var(--tracking-kicker)", textTransform: "uppercase", color: "var(--hc-blue-400)" }}>Bridgeport, West Virginia · Since 1988</div>
        <h1 style={{ font: "700 56px/1.08 var(--font-serif-display)", letterSpacing: "-0.01em", color: "#fff", maxWidth: 640, margin: "18px 0 0" }}>Built on Reputation.</h1>
        <p style={{ font: "19px/1.55 var(--font-sans)", color: "rgba(255,255,255,0.85)", maxWidth: 560, margin: "20px 0 32px" }}>
          For nearly four decades, Huffman Corporation has delivered commercial, institutional, and residential projects across North Central West Virginia — most of them for clients who came back.
        </p>
        <div style={{ display: "flex", gap: 14 }}>
          <Button size="lg" onClick={() => onNav("Contact")}>Request a Bid</Button>
          <Button size="lg" variant="onDark" onClick={() => onNav("Projects")}>View Our Work</Button>
        </div>
      </div>
    </section>
  );
}

const SERVICES = [
  { name: "Commercial", desc: "Offices, retail, and light industrial — ground-up construction and renovations for regional businesses." },
  { name: "Institutional", desc: "Schools, healthcare, and municipal facilities delivered on public timelines and budgets." },
  { name: "Residential", desc: "Custom homes and residential developments built to last generations." },
  { name: "Specialty", desc: "Complex and unconventional scopes other contractors pass on." },
];

function Services() {
  return (
    <section data-screen-label="Services" style={{ padding: "var(--section-pad) 0" }}>
      <div style={wrap}>
        <SectionHeading kicker="What We Build" title="Four Divisions, One Standard" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24, marginTop: 48 }}>
          {SERVICES.map((s) => (
            <div key={s.name} style={{ borderTop: "3px solid var(--brand)", background: "var(--surface-subtle)", padding: "24px 22px 26px" }}>
              <div style={{ font: "700 21px var(--font-serif-display)", color: "var(--text-heading)" }}>{s.name}</div>
              <p style={{ font: "14.5px/1.6 var(--font-sans)", color: "var(--text-body)", margin: "10px 0 0" }}>{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

const PROJECTS = [
  { title: "Bridgeport Middle School Addition", cat: "Institutional", year: "2024", desc: "22,000 sq ft classroom wing completed while school remained in session." },
  { title: "Meadowbrook Commerce Center", cat: "Commercial", year: "2023", desc: "Three-tenant retail and office shell with full sitework." },
  { title: "Simpson Creek Residence", cat: "Residential", year: "2024", desc: "Custom 4,200 sq ft home on a hillside site." },
  { title: "Regional Clinic Renovation", cat: "Institutional", year: "2022", desc: "Phased occupied renovation of an outpatient facility." },
  { title: "Route 50 Warehouse", cat: "Commercial", year: "2023", desc: "40,000 sq ft pre-engineered warehouse and yard." },
  { title: "Historic Storefront Restoration", cat: "Specialty", year: "2021", desc: "Facade restoration and structural repair downtown." },
];

function ProjectGrid({ limit, filter }) {
  let list = PROJECTS;
  if (filter && filter !== "All Projects") list = list.filter((p) => p.cat === filter);
  if (limit) list = list.slice(0, limit);
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 28 }}>
      {list.map((p) => (
        <Card key={p.title} imageLabel="Project Photo" meta={p.cat} title={p.title} lifted>
          {p.desc}
          <div style={{ marginTop: 12 }}><Badge tone="neutral" outline>Completed {p.year}</Badge></div>
        </Card>
      ))}
    </div>
  );
}

function ProjectsTeaser({ onNav }) {
  return (
    <section data-screen-label="Projects teaser" style={{ padding: "var(--section-pad) 0", background: "var(--surface-subtle)" }}>
      <div style={wrap}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 48 }}>
          <SectionHeading kicker="Our Work" title="Recent Projects" />
          <Button variant="secondary" onClick={() => onNav("Projects")}>All Projects</Button>
        </div>
        <ProjectGrid limit={3} />
      </div>
    </section>
  );
}

function StatsBand() {
  return (
    <section data-screen-label="Stats band" style={{ background: "var(--surface-dark)", padding: "72px 0" }}>
      <div style={{ ...wrap, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 32 }}>
        <Stat value="38" label="Years in Business" onDark />
        <Stat value="500+" label="Projects Completed" onDark />
        <Stat value="80%" label="Repeat Clients" onDark />
        <Stat value="4" label="Construction Divisions" onDark />
      </div>
    </section>
  );
}

function Clients() {
  const names = ["Harrison County Schools", "United Hospital Center", "City of Bridgeport", "WesBanco", "Meadowbrook Mall", "Dominion Energy"];
  return (
    <section data-screen-label="Clients" style={{ padding: "72px 0" }}>
      <div style={{ ...wrap, textAlign: "center" }}>
        <div style={{ font: "600 12.5px var(--font-sans)", letterSpacing: "var(--tracking-kicker)", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 32 }}>
          Trusted by clients across the region
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: 48, flexWrap: "wrap" }}>
          {names.map((n) => (
            <span key={n} style={{ font: "700 17px var(--font-serif-display)", color: "var(--hc-gray-300)", whiteSpace: "nowrap" }}>{n}</span>
          ))}
        </div>
        <p style={{ font: "12px var(--font-sans)", color: "var(--hc-gray-300)", marginTop: 28 }}>Client names shown as monotone placeholders — replace with monotone client logos.</p>
      </div>
    </section>
  );
}

function Footer({ onNav }) {
  return (
    <footer style={{ background: "var(--surface-dark)", padding: "56px 0 40px" }}>
      <div style={{ ...wrap, display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gap: 48 }}>
        <div>
          <div style={{ font: "700 22px var(--font-serif-display)", color: "#fff" }}>Huffman Corporation</div>
          <div style={{ font: "italic 600 12px var(--font-serif-display)", color: "var(--hc-blue-400)", marginTop: 4 }}>General Contractors · Construction Managers</div>
          <p style={{ font: "14px/1.7 var(--font-sans)", color: "var(--text-on-dark-muted)", maxWidth: 340, marginTop: 16 }}>
            Serving North Central West Virginia since 1988. Licensed, bonded, and insured.
          </p>
        </div>
        <div>
          <div style={{ font: "600 12.5px var(--font-sans)", letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--hc-blue-400)", marginBottom: 14 }}>Company</div>
          {["Projects", "Services", "About", "Contact"].map((l) => (
            <a key={l} href={"#" + l.toLowerCase()} onClick={(e) => { e.preventDefault(); onNav(l); }} style={{ display: "block", font: "14px var(--font-sans)", color: "rgba(255,255,255,0.85)", textDecoration: "none", padding: "5px 0" }}>{l}</a>
          ))}
        </div>
        <div>
          <div style={{ font: "600 12.5px var(--font-sans)", letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--hc-blue-400)", marginBottom: 14 }}>Contact</div>
          <div style={{ font: "14px/2 var(--font-sans)", color: "rgba(255,255,255,0.85)" }}>
            Bridgeport, West Virginia<br />
            (304) 555-0134<br />
            office@huffmancorp.example
          </div>
        </div>
      </div>
      <div style={{ ...wrap, borderTop: "1px solid rgba(255,255,255,0.14)", marginTop: 44, paddingTop: 22, font: "12.5px var(--font-sans)", color: "rgba(255,255,255,0.5)" }}>
        © 2026 Huffman Corporation. Wayne Huffman, Owner.
      </div>
    </footer>
  );
}

Object.assign(window, { HCHeader: Header, HCHero: Hero, HCServices: Services, HCProjectGrid: ProjectGrid, HCProjectsTeaser: ProjectsTeaser, HCStatsBand: StatsBand, HCClients: Clients, HCFooter: Footer, HCPhotoPlaceholder: PhotoPlaceholder, HCwrap: wrap });
